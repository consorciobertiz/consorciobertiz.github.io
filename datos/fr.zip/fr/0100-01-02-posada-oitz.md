---
layout: restaurante
category: restaurante
published: true
title: Posada de Oitz
telefono:
  - "948451951"
tags:
  - "martes-mediodia"
  - "miercoles-mediodia"
  - "miercoles-noche"
  - "jueves-mediodia"
  - "jueves-noche"
  - "viernes-mediodia"
  - "viernes-noche"
  - "sabado-mediodia"
  - "sabado-noche"
  - "domingo-mediodia"
  - "domingo-noche"
idioma: fr
---

12:30h. – 15:30h. / 20:00h. - 22:00h. (Entre semaine et dimanches) Vendredi jusqu'à 22:30h et samedi jusqu'à 23:00h

Menu du jour (14,50€), à la carte (precio medio: 25-26€), menu week end et menus thématiques.

HORS HORAIRE: Pinchos et hors d'oeuvres (les matins)

**25 Decembre fermé**

Oitz

[Plus information](http://www.consorciobertiz.org/consorcio/dondecomer/restaurantes/oitz-es-0-188/posada-de-oitz-es.html)

[Localiser sur la carte](https://maps.google.es/maps?q=Posada+de+Oitz&amp;hl=es&amp;sll=43.113641,-1.682539&amp;sspn=0.020395,0.038581&amp;t=h&amp;hq=Posada+de+Oitz&amp;z=15&amp;iwloc=A "Posada Oitz")
