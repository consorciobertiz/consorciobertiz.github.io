---
layout: restaurante
category: restaurante
published: true
title: Posada de Oitz
telefono:
  - "948451951"
tags:
  - "martes-mediodia"
  - "miercoles-mediodia"
  - "miercoles-noche"
  - "jueves-mediodia"
  - "jueves-noche"
  - "viernes-mediodia"
  - "viernes-noche"
  - "sabado-mediodia"
  - "sabado-noche"
  - "domingo-mediodia"
  - "domingo-noche"
idioma: eu
---

12:30h. - 15:30h. / 20:00h. -22:00h. (aste tartez eta igandeetan); 22:30 ortziraletan; 23:00 larunbatetan.

Eguneko menua (14,50€), karta (batazbesteko prezioa: 25-26€), asteburuko menua eta gaikako menuak.

ORDUTEGIZ KANPO: Pintxoak eta razioak (goizez)

**Abenduak 25 itxita**

Oitz

[Informazio gehiago](http://www.consorciobertiz.org/consorcio/dondecomer/restaurantes/oitz-es-0-188/posada-de-oitz-es.html)

[Mapan kokatu](https://maps.google.es/maps?q=Posada+de+Oitz&amp;hl=es&amp;sll=43.113641,-1.682539&amp;sspn=0.020395,0.038581&amp;t=h&amp;hq=Posada+de+Oitz&amp;z=15&amp;iwloc=A "Oitzeko Posada")
