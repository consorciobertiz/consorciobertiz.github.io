---
layout: restaurante
category: restaurante
published: true
title: Donamariako benta
telefono:
  - "948450708"
tags:
  - "martes-mediodia"
  - "martes-noche"
  - "miercoles-mediodia"
  - "miercoles-noche"
  - "jueves-mediodia"
  - "jueves-noche"
  - "viernes-mediodia"
  - "viernes-noche"
  - "sabado-mediodia"
  - "sabado-noche"
  - "domingo-mediodia"
idioma: eu
---

13:30h. - 15:30h. / 20:30h. - 22:15h.

Menuak (18€/25€).

**Abenduak 17tik Urtarrilak 4a itxita**

ORDUTEGIZ KANPO: Razioak (10:00 - 12:00)

Donamaria

[Informazio gehiago](http://www.consorciobertiz.org/consorcio/dondecomer/restaurantes/donamaria-es-0-176/restaurante-donamariako-benta.html)

[Mapan kokatu](https://maps.google.es/maps?q=donamaria%C2%B4ko+benta&amp;hl=es&amp;ie=UTF8&amp;ll=43.113641,-1.682539&amp;spn=0.020395,0.038581&amp;sll=43.113265,-1.681681&amp;sspn=0.020395,0.038581&amp;t=h&amp;hq=donamariako+benta&amp;z=15&amp;iwloc=A "Donamariako benta")
