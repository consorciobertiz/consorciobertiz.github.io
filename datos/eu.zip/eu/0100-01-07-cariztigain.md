---
layout: restaurante
category: restaurante
published: true
title: Camping Ariztigain
telefono:
  - "948450540"
tags:
  - "lunes-mediodia"
  - "martes-mediodia"
  - "miercoles-mediodia"
  - "jueves-mediodia"
  - "viernes-mediodia"
  - "viernes-noche"
  - "sabado-mediodia"
  - "sabado-noche"
  - "domingo-mediodia"
  - "domingo-noche"
idioma: eu
---

13:00h. – 15:15h. / 19:30h. – 22:15h.

Menua (11€), plater konbinautak, pintxoak, hanburgesak, sandwich-ak, bokatak, asteburuko menua (22€ y 32 €), kazuelak eta razioak.

ORDUTEGIZ KANPO:Pintxoak, gosariak eta razioak.

**Abenduak 15etik 31ra itxita**

Sunbilla

[Informazio gehiago](http://www.consorciobertiz.org/consorcio/dondecomer/restaurantes/sunbilla-es-0-190/restaurante-camping-ariztigain.html)

[Mapan kokatu](https://maps.google.es/maps?q=camping+ariztigain&amp;hl=es&amp;ll=43.186279,-1.672497&amp;spn=0.081482,0.154324&amp;sll=43.130208,-1.643753&amp;sspn=0.010195,0.01929&amp;t=h&amp;hq=camping+ariztigain&amp;z=13&amp;iwloc=A "Ariztigain kanpina")
