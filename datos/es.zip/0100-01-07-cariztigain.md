---
layout: restaurante
category: restaurante
published: true
title: Camping Ariztigain
telefono:
  - "948450540"
tags:
  - "lunes-mediodia"
  - "martes-mediodia"
  - "miercoles-mediodia"
  - "jueves-mediodia"
  - "viernes-mediodia"
  - "viernes-noche"
  - "sabado-mediodia"
  - "sabado-noche"
  - "domingo-mediodia"
  - "domingo-noche"
idioma: es
---

13:00-15:15/19:30-22:15

Menu (11€), platos combinados, pinchos, hamburguesas, sandwichs, bocatas, menu fin de semana (22€ y 32€), cazuelas y raciones

FUERA DE HORARIO: Pinchos, almuerzos y raciones

**Del 15 al 31 de Diciembre cerrado**

Sunbilla

[Más información](http://www.consorciobertiz.org/consorcio/dondecomer/restaurantes/sunbilla-es-0-190/restaurante-camping-ariztigain.html)

[Localizar en el mapa](https://maps.google.es/maps?q=camping+ariztigain&amp;hl=es&amp;ll=43.186279,-1.672497&amp;spn=0.081482,0.154324&amp;sll=43.130208,-1.643753&amp;sspn=0.010195,0.01929&amp;t=h&amp;hq=camping+ariztigain&amp;z=13&amp;iwloc=A "Camping Ariztigain")
