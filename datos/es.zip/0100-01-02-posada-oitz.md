---
layout: restaurante
category: restaurante
published: true
title: Posada de Oitz
telefono:
  - "948451951"
tags:
  - "martes-mediodia"
  - "miercoles-mediodia"
  - "miercoles-noche"
  - "jueves-mediodia"
  - "jueves-noche"
  - "viernes-mediodia"
  - "viernes-noche"
  - "sabado-mediodia"
  - "sabado-noche"
  - "domingo-mediodia"
  - "domingo-noche"
idioma: es
---

12:30h.–15:30h. / 20:00h.–22:00 (entre semana y domingos), 22:30 (viernes), 23:00 (sábados).

Menú del día (14,50€), carta (Precio medio: 25-26€), menú fin de semana y menús temáticos. FUERA DE HORARIO: Pinchos y raciones (por las mañanas)

**25 Diciembre cerrado.**

Oitz

[Más información](http://www.consorciobertiz.org/consorcio/dondecomer/restaurantes/oitz-es-0-188/posada-de-oitz-es.html)

[Localizar en el mapa](https://maps.google.es/maps?q=Posada+de+Oitz&amp;hl=es&amp;sll=43.113641,-1.682539&amp;sspn=0.020395,0.038581&amp;t=h&amp;hq=Posada+de+Oitz&amp;z=15&amp;iwloc=A "Posada Oitz")
