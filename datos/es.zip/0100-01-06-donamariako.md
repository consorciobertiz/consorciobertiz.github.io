---
layout: restaurante
category: restaurante
published: true
title: Donamariako benta
telefono:
  - "948450708"
tags:
  - "martes-mediodia"
  - "martes-noche"
  - "miercoles-mediodia"
  - "miercoles-noche"
  - "jueves-mediodia"
  - "jueves-noche"
  - "viernes-mediodia"
  - "viernes-noche"
  - "sabado-mediodia"
  - "sabado-noche"
  - "domingo-mediodia"
idioma: es
---

13:30h. – 15:30h. / 20:30h. – 22:15h.

Menús (18€ / 25€). FUERA DE HORARIO: Raciones (10:00 – 12:00)

**Del 17 de Diciembre al 4 de Enero cerrado.**

Donamaria

[Más información](http://www.consorciobertiz.org/consorcio/dondecomer/restaurantes/donamaria-es-0-176/restaurante-donamariako-benta.html)

[Localizar en el mapa](https://maps.google.es/maps?q=donamaria%C2%B4ko+benta&amp;hl=es&amp;ie=UTF8&amp;ll=43.113641,-1.682539&amp;spn=0.020395,0.038581&amp;sll=43.113265,-1.681681&amp;sspn=0.020395,0.038581&amp;t=h&amp;hq=donamariako+benta&amp;z=15&amp;iwloc=A "Donamariako benta")
