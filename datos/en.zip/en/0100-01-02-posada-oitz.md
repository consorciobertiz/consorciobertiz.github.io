---
layout: restaurante
category: restaurante
published: true
title: Posada de Oitz
telefono:
  - "948451951"
tags:
  - "martes-mediodia"
  - "miercoles-mediodia"
  - "miercoles-noche"
  - "jueves-mediodia"
  - "jueves-noche"
  - "viernes-mediodia"
  - "viernes-noche"
  - "sabado-mediodia"
  - "sabado-noche"
  - "domingo-mediodia"
  - "domingo-noche"
idioma: en
---

12:30 h. - 15:30 h. / 20:00 h. - 22:00 h. (Monday to thursday and sunday) Friday until 22:30 pm and Saturday to 23:00 h

Menu of the day (14.50 €), à la carte (average price: 25-26 €), weekend menu and themed menus.

OUT OF HOURS: snacks and portions (in the morning)

**25th December closed**

Oitz

[More information](http://www.consorciobertiz.org/consorcio/dondecomer/restaurantes/oitz-es-0-188/posada-de-oitz-es.html)

[Locate on the map](https://maps.google.es/maps?q=Posada+de+Oitz&amp;hl=es&amp;sll=43.113641,-1.682539&amp;sspn=0.020395,0.038581&amp;t=h&amp;hq=Posada+de+Oitz&amp;z=15&amp;iwloc=A "Posada Oitz")
