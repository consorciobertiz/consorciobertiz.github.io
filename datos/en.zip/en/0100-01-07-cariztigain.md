---
layout: restaurante
category: restaurante
published: true
title: Camping Ariztigain
telefono:
  - "948450540"
tags:
  - "lunes-mediodia"
  - "lunes-noche"
  - "martes-mediodia"
  - "martes-noche"
  - "miercoles-mediodia"
  - "miercoles-noche"
  - "jueves-mediodia"
  - "jueves-noche"
  - "viernes-mediodia"
  - "viernes-noche"
  - "sabado-mediodia"
  - "sabado-noche"
  - "domingo-mediodia"
  - "domingo-noche"
idioma: en
---

13:00. - 15:15 h. / 19:30 h. - 22:15 h

Menu (11 €), meals, snacks, sandwich burgers, sandwiches, weekend menu (22 € and 32 €), pans and portions.

OUT OF HOURS: snacks, meals and portions.

**Closed from 15 to 31 December**

Sunbilla

[More information](http://www.consorciobertiz.org/consorcio/dondecomer/restaurantes/sunbilla-es-0-190/restaurante-camping-ariztigain.html)

[Locate on the map](https://maps.google.es/maps?q=camping+ariztigain&amp;hl=es&amp;ll=43.186279,-1.672497&amp;spn=0.081482,0.154324&amp;sll=43.130208,-1.643753&amp;sspn=0.010195,0.01929&amp;t=h&amp;hq=camping+ariztigain&amp;z=13&amp;iwloc=A "Ariztigain Campsite")
